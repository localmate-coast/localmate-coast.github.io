/* Only load Google Analytics after an explicit choice. No free-text data is collected. */
(()=>{
  'use strict';
  const root=document.documentElement, lang=root.lang==='zh-Hans'?'zh':root.lang;
  const texts=JSON.parse(document.getElementById('experience-text').textContent);
  const id=root.dataset.measurement, path=location.pathname, cleanUrl=location.origin+path;
  const slug=path.split('/').filter(Boolean)[1]||'home';
  const dialog=document.getElementById('statistics-choice'), status=document.getElementById('experience-status');
  const storage={get:k=>{try{return localStorage.getItem(k);}catch{return null;}},set:(k,v)=>{try{localStorage.setItem(k,v);}catch{}}};
  let consent=storage.get('lm-statistics-v1'), ready=false, loading;
  const validId=/^G-[A-Z0-9]+$/.test(id||'') && location.protocol==='https:' && root.dataset.production==='true';
  function message(s){if(status)status.textContent=s;}
  function baseParams(){return {guide_slug:slug,site_language:lang,page_location:cleanUrl,page_title:document.title};}
  function load(){
    if(ready)return Promise.resolve(true);
    if(loading)return loading;
    if(!validId||consent!=='allow')return Promise.resolve(false);
    window.dataLayer=window.dataLayer||[];
    window.gtag=function(){window.dataLayer.push(arguments);};
    window.gtag('consent','default',{analytics_storage:'granted',ad_storage:'denied',ad_user_data:'denied',ad_personalization:'denied'});
    window.gtag('js',new Date());
    let ref='';try{const r=new URL(document.referrer);if(['www.google.com','www.google.co.kr','search.naver.com','m.search.naver.com','localmate-coast.github.io'].includes(r.hostname))ref=r.origin+'/';}catch{}
    window.gtag('config',id,{send_page_view:false,page_location:cleanUrl,page_referrer:ref,allow_google_signals:false,allow_ad_personalization_signals:false,cookie_expires:60*60*24*90,cookie_update:false});
    loading=new Promise(resolve=>{
      const script=document.createElement('script');script.src='https://www.googletagmanager.com/gtag/js?id='+id;script.async=true;
      const timer=setTimeout(()=>resolve(false),8000);
      script.onload=()=>{clearTimeout(timer);ready=true;window.gtag('event','page_view',baseParams());resolve(true);};
      script.onerror=()=>{clearTimeout(timer);resolve(false);};
      document.head.append(script);
    });return loading;
  }
  async function track(name,params={}){if(consent!=='allow')return false;if(!await load())return false;window.gtag('event',name,{...baseParams(),...params,transport_type:'beacon'});return true;}
  function open(){if(!dialog.open)dialog.showModal();}
  document.querySelectorAll('[data-statistics-settings]').forEach(b=>b.addEventListener('click',open));
  document.querySelector('[data-close-consent]').addEventListener('click',()=>dialog.close());
  document.querySelectorAll('[data-consent]').forEach(b=>b.addEventListener('click',()=>{
    const previous=consent;consent=b.dataset.consent;storage.set('lm-statistics-v1',consent);dialog.close();
    if(consent==='allow')load();
    else{
      window['ga-disable-'+id]=true;
      document.cookie.split(';').map(c=>c.trim().split('=')[0]).filter(n=>n==='_ga'||n.startsWith('_ga_')).forEach(n=>{for(const domain of ['',location.hostname,'.'+location.hostname])document.cookie=n+'=; Max-Age=0; Path=/'+(domain?'; Domain='+domain:'')+'; SameSite=Lax; Secure';});
      if(previous==='allow')location.reload();
    }
    if(consent==='allow')window['ga-disable-'+id]=false;
  }));
  if(consent==='allow')load();else if(!consent&&validId)open();
  document.querySelectorAll('[data-tool]').forEach(a=>a.addEventListener('click',()=>track('guide_tool_click',{tool_id:a.dataset.tool})));
  document.querySelectorAll('[data-feedback]').forEach(b=>b.addEventListener('click',async()=>{
    if(consent!=='allow'){message(texts.needsConsent);open();return;}
    const key='lm-feedback:'+lang+':'+slug;
    if(storage.get(key)){message(texts.already);return;}
    b.disabled=true;const sent=await track('guide_feedback',{feedback_choice:b.dataset.feedback});
    if(sent){storage.set(key,b.dataset.feedback);document.querySelectorAll('[data-feedback]').forEach(btn=>btn.disabled=true);message(texts.queued);}
    else{b.disabled=false;message(texts.unavailable);}
  }));
  document.querySelectorAll('[data-check]').forEach(input=>{
    const key='lm-check:'+lang+':'+slug+':'+input.dataset.check;
    input.checked=storage.get(key)==='1';input.addEventListener('change',()=>{storage.set(key,input.checked?'1':'0');if(input.checked)track('guide_check',{check_item:input.dataset.check});});
  });
  document.querySelectorAll('[data-copy-place]').forEach(b=>b.addEventListener('click',async()=>{
    try{await navigator.clipboard.writeText(b.dataset.copyPlace);message(texts.copied);track('place_copy',{place_id:b.dataset.placeId});}catch{message(texts.copyFail);}
  }));
  document.querySelectorAll('[data-share]').forEach(b=>b.addEventListener('click',async()=>{
    try{if(navigator.share){await navigator.share({title:document.title,url:cleanUrl});message(texts.shared);}else{await navigator.clipboard.writeText(cleanUrl);message(texts.shareCopy);}track('guide_share');}
    catch(e){if(e.name!=='AbortError')message(texts.shareFail);}
  }));
  let scrolled=false;window.addEventListener('scroll',()=>{const height=document.documentElement.scrollHeight;if(!scrolled&&height>innerHeight&&scrollY+innerHeight>=height*.9&&consent==='allow'){scrolled=true;track('scroll',{percent_scrolled:90});}},{passive:true});
})();
